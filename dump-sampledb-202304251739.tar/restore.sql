--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.0
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sampledb;
--
-- Name: sampledb; Type: DATABASE; Schema: -; Owner: robby parlan
--

CREATE DATABASE sampledb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Indonesian_Indonesia.1252';


ALTER DATABASE sampledb OWNER TO "robby parlan";

\connect sampledb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: robby parlan
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO "robby parlan";

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: robby parlan
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

--
-- Name: api_clients; Type: TABLE; Schema: public; Owner: dbadmin
--

CREATE TABLE public.api_clients (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone,
    client_id character varying(50) NOT NULL,
    secret_key character varying(100),
    grant_type character varying(20) DEFAULT 'credentials'::character varying NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    jwt_age integer
);


ALTER TABLE public.api_clients OWNER TO dbadmin;

--
-- Name: api_clients_id_seq; Type: SEQUENCE; Schema: public; Owner: dbadmin
--

CREATE SEQUENCE public.api_clients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_clients_id_seq OWNER TO dbadmin;

--
-- Name: api_clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbadmin
--

ALTER SEQUENCE public.api_clients_id_seq OWNED BY public.api_clients.id;


--
-- Name: menus; Type: TABLE; Schema: public; Owner: dbadmin
--

CREATE TABLE public.menus (
    id character varying(10) NOT NULL,
    menu_name character varying(20) NOT NULL,
    order_no integer
);


ALTER TABLE public.menus OWNER TO dbadmin;

--
-- Name: r_config; Type: TABLE; Schema: public; Owner: dbadmin
--

CREATE TABLE public.r_config (
    code character varying(50) NOT NULL,
    type character varying(10),
    value text,
    description character varying(200)
);


ALTER TABLE public.r_config OWNER TO dbadmin;

--
-- Name: role_access; Type: TABLE; Schema: public; Owner: dbadmin
--

CREATE TABLE public.role_access (
    id integer NOT NULL,
    role_id character varying(10) NOT NULL,
    menu_id character varying(10) NOT NULL
);


ALTER TABLE public.role_access OWNER TO dbadmin;

--
-- Name: role_access_id_seq; Type: SEQUENCE; Schema: public; Owner: dbadmin
--

CREATE SEQUENCE public.role_access_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_access_id_seq OWNER TO dbadmin;

--
-- Name: role_access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbadmin
--

ALTER SEQUENCE public.role_access_id_seq OWNED BY public.role_access.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: dbadmin
--

CREATE TABLE public.roles (
    id character varying(10) NOT NULL,
    role_name character varying(20) NOT NULL,
    order_no integer
);


ALTER TABLE public.roles OWNER TO dbadmin;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: dbadmin
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO dbadmin;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbadmin
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: dbadmin
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(20) NOT NULL,
    fullname character varying(100),
    email character varying(50) NOT NULL,
    password character varying(100),
    phone character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    role_id character varying(10) NOT NULL,
    is_active boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO dbadmin;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: dbadmin
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO dbadmin;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbadmin
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: watermonitoring; Type: TABLE; Schema: public; Owner: dbadmin
--

CREATE TABLE public.watermonitoring (
    id integer NOT NULL,
    createtime bigint,
    temperature character varying(100),
    ph character varying(100),
    tds character varying(100),
    nh3n character varying(100),
    tss character varying(100),
    turbidity character varying(100),
    "do" character varying(100),
    no3 character varying(100),
    cod character varying(100),
    bod character varying(100),
    waterlevel character varying(100),
    is_success boolean DEFAULT false,
    sync_time timestamp without time zone,
    res_menlhk text,
    exec_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.watermonitoring OWNER TO dbadmin;

--
-- Name: watermonitoring_id_seq; Type: SEQUENCE; Schema: public; Owner: dbadmin
--

CREATE SEQUENCE public.watermonitoring_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.watermonitoring_id_seq OWNER TO dbadmin;

--
-- Name: watermonitoring_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbadmin
--

ALTER SEQUENCE public.watermonitoring_id_seq OWNED BY public.watermonitoring.id;


--
-- Name: api_clients id; Type: DEFAULT; Schema: public; Owner: dbadmin
--

ALTER TABLE ONLY public.api_clients ALTER COLUMN id SET DEFAULT nextval('public.api_clients_id_seq'::regclass);


--
-- Name: role_access id; Type: DEFAULT; Schema: public; Owner: dbadmin
--

ALTER TABLE ONLY public.role_access ALTER COLUMN id SET DEFAULT nextval('public.role_access_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: dbadmin
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: watermonitoring id; Type: DEFAULT; Schema: public; Owner: dbadmin
--

ALTER TABLE ONLY public.watermonitoring ALTER COLUMN id SET DEFAULT nextval('public.watermonitoring_id_seq'::regclass);


--
-- Data for Name: api_clients; Type: TABLE DATA; Schema: public; Owner: dbadmin
--

COPY public.api_clients (id, created_at, updated_at, client_id, secret_key, grant_type, is_active, jwt_age) FROM stdin;
\.
COPY public.api_clients (id, created_at, updated_at, client_id, secret_key, grant_type, is_active, jwt_age) FROM '$$PATH$$/2865.dat';

--
-- Data for Name: menus; Type: TABLE DATA; Schema: public; Owner: dbadmin
--

COPY public.menus (id, menu_name, order_no) FROM stdin;
\.
COPY public.menus (id, menu_name, order_no) FROM '$$PATH$$/2870.dat';

--
-- Data for Name: r_config; Type: TABLE DATA; Schema: public; Owner: dbadmin
--

COPY public.r_config (code, type, value, description) FROM stdin;
\.
COPY public.r_config (code, type, value, description) FROM '$$PATH$$/2873.dat';

--
-- Data for Name: role_access; Type: TABLE DATA; Schema: public; Owner: dbadmin
--

COPY public.role_access (id, role_id, menu_id) FROM stdin;
\.
COPY public.role_access (id, role_id, menu_id) FROM '$$PATH$$/2869.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: dbadmin
--

COPY public.roles (id, role_name, order_no) FROM stdin;
\.
COPY public.roles (id, role_name, order_no) FROM '$$PATH$$/2867.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: dbadmin
--

COPY public.users (id, username, fullname, email, password, phone, created_at, updated_at, role_id, is_active) FROM stdin;
\.
COPY public.users (id, username, fullname, email, password, phone, created_at, updated_at, role_id, is_active) FROM '$$PATH$$/2872.dat';

--
-- Data for Name: watermonitoring; Type: TABLE DATA; Schema: public; Owner: dbadmin
--

COPY public.watermonitoring (id, createtime, temperature, ph, tds, nh3n, tss, turbidity, "do", no3, cod, bod, waterlevel, is_success, sync_time, res_menlhk, exec_count) FROM stdin;
\.
COPY public.watermonitoring (id, createtime, temperature, ph, tds, nh3n, tss, turbidity, "do", no3, cod, bod, waterlevel, is_success, sync_time, res_menlhk, exec_count) FROM '$$PATH$$/2875.dat';

--
-- Name: api_clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbadmin
--

SELECT pg_catalog.setval('public.api_clients_id_seq', 1, true);


--
-- Name: role_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbadmin
--

SELECT pg_catalog.setval('public.role_access_id_seq', 5, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbadmin
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbadmin
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: watermonitoring_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbadmin
--

SELECT pg_catalog.setval('public.watermonitoring_id_seq', 8, true);


--
-- Name: menus menus_pk; Type: CONSTRAINT; Schema: public; Owner: dbadmin
--

ALTER TABLE ONLY public.menus
    ADD CONSTRAINT menus_pk PRIMARY KEY (id);


--
-- Name: r_config pk_r_config; Type: CONSTRAINT; Schema: public; Owner: dbadmin
--

ALTER TABLE ONLY public.r_config
    ADD CONSTRAINT pk_r_config PRIMARY KEY (code);


--
-- Name: role_access role_access_pk; Type: CONSTRAINT; Schema: public; Owner: dbadmin
--

ALTER TABLE ONLY public.role_access
    ADD CONSTRAINT role_access_pk PRIMARY KEY (id);


--
-- Name: roles roles_pk; Type: CONSTRAINT; Schema: public; Owner: dbadmin
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pk PRIMARY KEY (id);


--
-- Name: users users_pk; Type: CONSTRAINT; Schema: public; Owner: dbadmin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pk PRIMARY KEY (id);


--
-- Name: watermonitoring watermonitoring_pk; Type: CONSTRAINT; Schema: public; Owner: dbadmin
--

ALTER TABLE ONLY public.watermonitoring
    ADD CONSTRAINT watermonitoring_pk PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

